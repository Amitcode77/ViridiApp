# Viridi
Viridi - this application is focused on decreasing the pollution level in India and empowering farmers by allowing them to sell the stubble (commonly known as parali). 
The burning of stubble is one of the greatest reasons behind pollution in Delhi. By providing farmers the opportunity to sell the stubble and crafts made by stubble to various industries throughout India,
it will result in less pollution and this will increase the overall income of all farmers and providing them money for waste management and also allow various industries to grow and create Atmnirbhar Bharat. 
Also, you can learn to make use of stubble using our application so that a person can learn the required skills to make use of stubble and create more opportunities for making money for himself and also for others.
Supporting the idea of PMKVY.

Working of Viridi:
The user first register on the app and his/her data will be stored in our database  then the user can select according to their requirements from these options
1. Sell Stubble- This option will allow them to post ads on our app by uploading a picture and filling few details like how much stubble do they have, in which location and type of Stubbles also allow them to set a reasonable price on their stubble by providing them an average price

2. Buy Stubble - the option is for industry persons mainly so that they can buy raw materials i.e. Stubbles from nearest farmers directly which will also decrease their product shipment cost.

3. Craft Market - this option will allow our user to buy and sell products made up of Stubbles encouraging the use of Stubbles and empowering small businesses.

4. BOOK VEHICLE - this option allows our users to check the availability of shipping vehicles and book them according to their requirements. 

5. SKILLS - this option can be used by the user to learn the uses of Stubbles.  And making lots of opportunities to earn money 

The users can also see the status of their ads and their order history.
